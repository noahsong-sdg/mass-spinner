import {AMU,E_CHARGE,type Vec} from './physics.js';

/** Equal-weight ion representatives. Density belongs to the entire local cell. */
export interface CoulombIon {velocity:Vec;massU:number;chargeState:number}
export const EPSILON_0=8.8541878128e-12;
const checkIon=(p:CoulombIon)=>{
 if(!Number.isFinite(p.massU)||p.massU<=0||!Number.isSafeInteger(p.chargeState)||p.chargeState<1
  ||p.velocity.length!==3||!p.velocity.every(Number.isFinite))throw new Error('Coulomb ions require positive mass/integer charge and finite 3D velocity.');
};
const checkParameters=(density:number,log:number,dt:number)=>{
 if(![density,log,dt].every(Number.isFinite)||density<0||log<=0||dt<0)
  throw new Error('Coulomb density/time must be nonnegative and Coulomb logarithm positive.');
};
const uniform=(random:()=>number)=>{
 const u=random();if(!Number.isFinite(u)||u<0||u>=1)throw new Error('Collision RNG must return uniform values in [0,1).');return u;
};

/** TA variance of tan(theta/2), SI units; density is the effective partner density.
 * Identical velocities have no pair exchange. No relative-speed floor is used.
 */
export function coulombVariance(a:CoulombIon,b:CoulombIon,densityM3:number,coulombLog:number,dt:number):number{
 checkIon(a);checkIon(b);checkParameters(densityM3,coulombLog,dt);
 const g=Math.hypot(...a.velocity.map((v,i)=>v-b.velocity[i]));
 if(g===0||densityM3===0||dt===0)return 0;
 const mu=AMU*a.massU*b.massU/(a.massU+b.massU);
 const variance=(a.chargeState*b.chargeState*E_CHARGE**2/EPSILON_0/mu)**2*densityM3*coulombLog*dt/(8*Math.PI*g**3);
 if(!Number.isFinite(variance))throw new Error('Coulomb angular variance exceeds the finite numerical domain.');
 return variance;
}

/** Conservative Takizuka–Abe pair rotation. Large variances remain explicit
 * finite-step approximations; callers must report and converge their frequency.
 */
export function scatterCoulombPair(a:CoulombIon,b:CoulombIon,densityM3:number,coulombLog:number,dt:number,random:()=>number){
 const variance=coulombVariance(a,b,densityM3,coulombLog,dt);
 if(variance===0)return {velocityA:[...a.velocity] as Vec,velocityB:[...b.velocity] as Vec,variance};
 const relative=a.velocity.map((v,i)=>v-b.velocity[i]) as Vec,g=Math.hypot(...relative);
 const direction=relative.map(v=>v/g) as Vec;
 // Choose a numerically nonsingular perpendicular basis. Uniform azimuth makes
 // its arbitrary orientation immaterial to the rotationally invariant law.
 const axis=direction.reduce((best,v,i)=>Math.abs(v)<Math.abs(direction[best])?i:best,0);
 const basis:[number,number,number]=[0,0,0];basis[axis]=1;
 const cross:Vec=[direction[1]*basis[2]-direction[2]*basis[1],direction[2]*basis[0]-direction[0]*basis[2],direction[0]*basis[1]-direction[1]*basis[0]];
 const norm=Math.hypot(...cross),e1=cross.map(v=>v/norm) as Vec;
 const e2:Vec=[direction[1]*e1[2]-direction[2]*e1[1],direction[2]*e1[0]-direction[0]*e1[2],direction[0]*e1[1]-direction[1]*e1[0]];
 const delta=Math.sqrt(variance)*Math.sqrt(-2*Math.log1p(-uniform(random)))*Math.cos(2*Math.PI*uniform(random));
 const angle=2*Math.PI*uniform(random),square=delta*delta;
 // Reciprocal form also avoids overflow for an otherwise finite large delta.
 const cosine=Math.abs(delta)>1?(1/square-1)/(1/square+1):(1-square)/(1+square);
 const sine=Math.abs(delta)>1?2/(delta+1/delta):2*delta/(1+square);
 const rotated=direction.map((v,i)=>g*(v*cosine+(e1[i]*Math.cos(angle)+e2[i]*Math.sin(angle))*sine)) as Vec;
 const fractionA=a.massU/(a.massU+b.massU),fractionB=b.massU/(a.massU+b.massU);
 const center=a.velocity.map((v,i)=>fractionA*v+fractionB*b.velocity[i]);
 return {velocityA:center.map((v,i)=>v+fractionB*rotated[i]) as Vec,
  velocityB:center.map((v,i)=>v-fractionA*rotated[i]) as Vec,variance};
}

/** Random-batch empirical Landau approximation, all species mixed, equal weight.
 * Each other representative contributes n/N to the infinitesimal generator:
 * even N partner probability=1/(N-1), odd N=1/N (one uniformly unpaired ion).
 * This explicit finite-N normalization differs from species-separated TA pairing.
 * Mutates velocities only; positions/species/weights remain the caller's data.
 */
export function collideCoulombCell(ions:CoulombIon[],densityM3:number,coulombLog:number,dt:number,random:()=>number,
 onPair?:(a:CoulombIon,b:CoulombIon,deltaMomentumA:Vec)=>void){
 checkParameters(densityM3,coulombLog,dt);ions.forEach(checkIon);
 const n=ions.length,order=Array.from({length:n},(_,i)=>i);
 const diagnostics={pairs:0,maxVariance:0,meanVariance:0,largeAnglePairs:0,unpaired:n%2,zeroRelativePairs:0};
 if(n<2||densityM3===0||dt===0)return diagnostics;
 for(let i=n-1;i>0;i--){const j=Math.floor(uniform(random)*(i+1));[order[i],order[j]]=[order[j],order[i]];}
 const effectiveDensity=densityM3*(n%2?1:(n-1)/n);
 for(let i=0;i+1<n;i+=2){
  const a=ions[order[i]],b=ions[order[i+1]];
  const result=scatterCoulombPair(a,b,effectiveDensity,coulombLog,dt,random);
  diagnostics.pairs++;diagnostics.maxVariance=Math.max(diagnostics.maxVariance,result.variance);
  diagnostics.meanVariance+=result.variance;if(result.variance>.1)diagnostics.largeAnglePairs++;
  if(a.velocity.every((v,j)=>v===b.velocity[j]))diagnostics.zeroRelativePairs++;
  onPair?.(a,b,result.velocityA.map((v,j)=>(v-a.velocity[j])*a.massU*AMU) as Vec);
  a.velocity=result.velocityA;b.velocity=result.velocityB;
 }
 diagnostics.meanVariance/=diagnostics.pairs;
 return diagnostics;
}

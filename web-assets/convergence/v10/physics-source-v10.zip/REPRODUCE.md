# Executed Mass Spinner physics sources and case inputs

This is a physics/statistics reproduction bundle, not the complete web UI or Blender assets. It includes the exact executed import graphs, pinned package manifests, prospective plans, aggregation/audit sources and selected collision tests. Raw evidence and part hashes are downloadable separately. Node 22.23.1 was used; cross-platform bitwise identity is not promised.

Install the pinned dependencies with `npm ci` in your isolated development environment, then run:

```
./node_modules/.bin/tsx --test tests/axisymmetric-collisions.test.ts tests/axisymmetric-integration.test.ts tests/review-axisymmetric.test.ts
./node_modules/.bin/tsx scripts/run-convergence.ts --method axisymmetric --source-aligned --output assets/reproduced-source-fitted.json
./node_modules/.bin/tsx scripts/run-convergence.ts --plan assets/convergence-axisymmetric-fine-dt-plan-v10.json --output assets/reproduced-fine-dt.json
./node_modules/.bin/tsx scripts/run-convergence.ts --plan assets/convergence-confirmation-plan-v10.json --output assets/reproduced-confirmation.json
./node_modules/.bin/tsx scripts/check-ring-equilibrium-v10.ts
```

Run full plans without dropping seeds or retuning tolerances. Existing output paths are refused. The archived aggregators expect separately generated part artifacts and their original filenames. Audit scripts expect the corresponding downloaded original artifacts in assets. Software execution is separate from continuum and experimental validation; see the included method/plan reports. All configurations are teaching assumptions, not measurements.

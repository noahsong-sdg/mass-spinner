/** Archived one-campaign aggregation artifact; not production engine code.
 * All eighteen predeclared runs are mandatory. No estimates are recomputed by
 * a different method: the frozen production summarizeConvergence is reused.
 */
import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import {relative} from 'node:path';
import {summarizeConvergence,validateConvergencePlan} from '../src/convergence.ts';

const sha=(bytes:Uint8Array|string)=>createHash('sha256').update(bytes).digest('hex');
const planPath='assets/convergence-axisymmetric-fine-dt-plan-v10.json';
const planBytes=readFileSync(planPath),plan=JSON.parse(planBytes.toString());
validateConvergencePlan(plan);
const output='assets/convergence-axisymmetric-fine-dt-v10.json';
const outputs=[output,output.replace(/\.json$/,'.summary.json'),output.replace(/\.json$/,'.md')];
assert.ok(!outputs.some(existsSync),'Refusing to replace existing aggregate evidence.');
const parts=[1,2,3].map(i=>{
 const path=`assets/convergence-axisymmetric-fine-dt-v10-part${i}.json`,bytes=readFileSync(path);
 return {path,sha256:sha(bytes),artifact:JSON.parse(bytes.toString())};
});
const sourceHash=parts[0].artifact.sourceHash,sourceFiles=parts[0].artifact.sourceFiles;
assert.equal(sourceHash,sha(JSON.stringify(sourceFiles)));
for(const [path,expected]of Object.entries(sourceFiles))assert.equal(sha(readFileSync(path)),expected,`Source drift: ${path}`);
const strip=(p:Record<string,unknown>)=>Object.fromEntries(Object.entries(p).filter(([k])=>!['id','description','seeds'].includes(k)));
const allSeeds=parts.flatMap(p=>p.artifact.plan.seeds);
assert.deepEqual([...allSeeds].sort((a,b)=>a-b),[...plan.seeds].sort((a,b)=>a-b));
assert.equal(new Set(allSeeds).size,plan.seeds.length);
for(const {artifact:a}of parts){
 assert.equal(a.modelVersion,10);assert.equal(a.schemaVersion,1);
 assert.equal(a.sourceHash,sourceHash);assert.deepEqual(a.sourceFiles,sourceFiles);
 assert.deepEqual(strip(a.plan),strip(plan),'Chunk changes more than identity/seed subset.');
 assert.equal(a.runs.length,a.plan.levels.length*a.plan.seeds.length);
 assert.ok(a.runs.every(r=>r.status==='complete'&&r.sourceHash===sourceHash));
}
const unordered=parts.flatMap(p=>p.artifact.runs);
const runs=plan.levels.flatMap(level=>plan.seeds.map(seed=>{
 const matches=unordered.filter(r=>r.level===level.id&&r.seed===seed);
 assert.equal(matches.length,1,'Each declared level/seed must appear exactly once.');
 assert.deepEqual(matches[0].config,{...level.config,seed});return matches[0];
}));
assert.equal(runs.length,18);
const summary=summarizeConvergence(plan,runs,sourceHash);
for(const [path,expected]of Object.entries(sourceFiles))assert.equal(sha(readFileSync(path)),expected,`Source drift during aggregation: ${path}`);
assert.equal(sha(readFileSync(planPath)),sha(planBytes),'Original plan changed during aggregation.');
for(const part of parts)assert.equal(sha(readFileSync(part.path)),part.sha256,'Chunk changed during aggregation.');
const startedAt=parts.map(p=>p.artifact.startedAt).sort()[0];
const completedAt=parts.map(p=>p.artifact.completedAt).sort().at(-1)!;
const codePath=relative(process.cwd(),fileURLToPath(import.meta.url));
const artifact={schemaVersion:1,modelVersion:10,sourceHash,sourceFiles,startedAt,completedAt,
 environment:{...parts[0].artifact.environment,runner:'Three concurrent sequential CLI chunks (two predeclared seeds each); external frozen-statistics aggregation.'},
 durationMs:Date.parse(completedAt)-Date.parse(startedAt),plan,summary,runs,
 aggregation:{schemaVersion:1,createdAt:new Date().toISOString(),originalPlan:{path:planPath,sha256:sha(planBytes)},
  sourceCode:{path:codePath,sha256:sha(readFileSync(fileURLToPath(import.meta.url)))},
  parts:parts.map(p=>({path:p.path,sha256:p.sha256,plan:p.artifact.plan,startedAt:p.artifact.startedAt,
   completedAt:p.artifact.completedAt,durationMs:p.artifact.durationMs,sourceHash:p.artifact.sourceHash})),
  summedChunkWallDurationMs:parts.reduce((s,p)=>s+p.artifact.durationMs,0),
  summedRunWallDurationMs:runs.reduce((s,r)=>s+r.durationMs,0),
  interpretation:'Wall times include concurrent CPU contention; their sum is not measured CPU time. All original levels, seeds, physical settings and tolerances are retained. Chunk summaries are not acceptance certificates.'}};
writeFileSync(outputs[0],JSON.stringify(artifact,null,2)+'\n',{flag:'wx'});
writeFileSync(outputs[1],JSON.stringify({...artifact,runs:runs.map(({raw,...r})=>r)},null,2)+'\n',{flag:'wx'});
const fmt=(n:number|null)=>n===null?'undefined':n.toPrecision(6);
const markdown=[`# Convergence case: ${plan.id}`,'',plan.description,'',`**Gate: ${summary.status.toUpperCase()}.** Numerical evidence only; not experimental validation.`,
 `Model 10; executed graph \`${sourceHash}\`. Eighteen whole runs, six seeds per level. Three concurrent two-seed CLI chunks were aggregated without changing the frozen solver/statistics.`,
 '',summary.inference,'','| Level | End A mean ± 95% half-width | End B | Maximum raw P residual | Maximum unresolved exposure |',
 '| --- | --- | --- | --- | --- |',...plan.levels.map(level=>{
  const stats=summary.summaries[level.id],batch=runs.filter(r=>r.level===level.id);
  const a=stats['A.fraction.end'],b=stats['B.fraction.end'];
  return `| ${level.id} | ${fmt(a.mean)} ± ${fmt(a.halfWidth95)} | ${fmt(b.mean)} ± ${fmt(b.halfWidth95)} | ${fmt(Math.max(...batch.map(r=>r.diagnostics.maxRawMomentumResidual)))} | ${fmt(Math.max(...batch.map(r=>r.diagnostics.unresolvedExposure??1)))} |`;
 }),'','| Check | Status | Reason |','| --- | --- | --- |',...summary.checks.map(c=>`| ${c.name} | ${c.status} | ${c.reason} |`),'',
 'All original error budgets and configurations are in the JSON. Aggregation records original-plan, part-file and code hashes, configurations, timestamps and timing semantics. Each part retains the full executed graph. The exact aggregation source is archived separately from production code.',
 '',`Full evidence: \`${output}\`; compact evidence: \`${outputs[1]}\`. No optional stopping, seed removal or tolerance adjustment was used.`,''];
writeFileSync(outputs[2],markdown.join('\n'),{flag:'wx'});
console.log(`Aggregated all ${runs.length} runs into ${output}: ${summary.status}`);

"""Independent arithmetic/provenance audit; no simulator imports or execution."""
from pathlib import Path
import hashlib,json,math,sys

ROOT=Path(__file__).resolve().parents[1]
PATH=ROOT/'assets/convergence-confirmation-v10.json'
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads((ROOT/p).read_text())
same=lambda a,b:a==b or a is not None and b is not None and abs(a-b)<=max(1e-14,1e-10*max(abs(a),abs(b)))

def interval(values):
    n=len(values)
    if not n:return dict(n=0,mean=None,standardError=None,halfWidth95=None)
    mean=sum(values)/n
    if n<2:return dict(n=n,mean=mean,standardError=None,halfWidth95=None)
    error=math.sqrt(sum((x-mean)**2 for x in values)/(n*(n-1)))
    # The frozen declared method uses six-decimal Student-t quantiles.
    quantiles={15:2.131450}
    assert n-1 in quantiles,('Unexpected sample count',n)
    spread=max(values)-min(values)
    resolved=spread>256*sys.float_info.epsilon*max(abs(x) for x in values)
    return dict(n=n,mean=mean,standardError=error,halfWidth95=quantiles[n-1]*error if resolved else None)

def compare_interval(reported,values,where):
    expected=interval(values)
    for key,value in expected.items():assert same(reported[key],value),(where,key,reported[key],value)
    return expected

def tolerance(key,plan):
    t=plan['tolerances']
    if '.fraction.' in key or '.cdf.' in key:return t['fraction']
    if key.endswith('.radius'):return t['radiusFraction']
    if key.endswith('.temperature'):return t['temperatureEV']
    if key.endswith('.angularTransfer'):return t['normalizedAngularMomentum']
    if '.impactTime.' in key:return t['timeFraction']
    return None

artifact=json.loads(PATH.read_text());plan=artifact['plan']
original=read('assets/convergence-axisymmetric-refinement-plan-v10.json')
declared=read('assets/convergence-confirmation-plan-v10.json')
assert plan==declared
assert artifact['schemaVersion']==1 and artifact['modelVersion']==10
assert plan['seeds']==list(range(1001,1017))
assert plan['tolerances']==original['tolerances']
assert plan['levels']==original['levels'][1:]
assert plan['physicalEffect']==original['physicalEffect']
assert plan['comparisons']==original['comparisons'][1:]
source=artifact['sourceFiles']
assert sha(json.dumps(source,separators=(',',':'),ensure_ascii=False).encode())==artifact['sourceHash']
for path,digest in source.items():assert sha((ROOT/path).read_bytes())==digest,('Source drift',path)
aggregation=artifact['aggregation']
for reference in [aggregation['originalPlan'],aggregation['sourceCode'],*aggregation['parts']]:
    assert sha((ROOT/reference['path']).read_bytes())==reference['sha256'],reference['path']
parts=[read(p['path']) for p in aggregation['parts']]
assert sorted(s for p in parts for s in p['plan']['seeds'])==plan['seeds']
assert len(parts)==4
for p in parts:
    assert p['sourceHash']==artifact['sourceHash'] and p['sourceFiles']==source
    assert len(p['runs'])==12
    for key,value in plan.items():
        if key not in ['id','description','seeds']:assert p['plan'][key]==value,key
assert len(artifact['runs'])==48
runs={(r['level'],r['seed']):r for r in artifact['runs']}
assert len(runs)==48
assert set(runs)=={(level['id'],seed) for level in plan['levels'] for seed in plan['seeds']}
for level in plan['levels']:
    for seed in plan['seeds']:
        r=runs[(level['id'],seed)]
        assert r['status']=='complete' and r['sourceHash']==artifact['sourceHash']
        assert r['config']==dict(level['config'],seed=seed)
        part_runs=[x for p in parts for x in p['runs'] if x['level']==level['id'] and x['seed']==seed]
        assert len(part_runs)==1 and r==part_runs[0]
summaries=artifact['summary']['summaries'];summary_count=0
for level in plan['levels']:
    for key,reported in summaries[level['id']].items():
        values=[runs[(level['id'],seed)]['observables'][key] for seed in plan['seeds']]
        compare_interval(reported,[v for v in values if v is not None],(level['id'],key));summary_count+=1
paired_count=0
for comparison in artifact['summary']['comparisons']:
    verdicts=[]
    for key,reported in comparison['observables'].items():
        pairs=[(runs[(comparison['coarse'],s)]['observables'][key],runs[(comparison['fine'],s)]['observables'][key]) for s in plan['seeds']]
        values=[b-a for a,b in pairs if a is not None and b is not None]
        expected=compare_interval(reported,values,(comparison['coarse'],comparison['fine'],key))
        budget=tolerance(key,plan);assert reported['tolerance']==budget
        status='unknown';width=expected['halfWidth95'];mean=expected['mean']
        if budget is not None and len(values)==16 and width is not None:
            if abs(mean)+width<=budget:status='pass'
            elif abs(mean)-width>budget:status='fail'
        assert reported['status']==status,(key,status,reported['status'])
        if budget is not None:verdicts.append(status)
        paired_count+=1
    expected_status='fail' if 'fail' in verdicts else 'pass' if verdicts and all(v=='pass' for v in verdicts) else 'unknown'
    assert comparison['status']==expected_status
effect=plan['physicalEffect'];effect_count=0
for key,reported in artifact['summary']['physicalEffect'].items():
    pairs=[(runs[(effect['control'],s)]['observables'][key],runs[(effect['collisional'],s)]['observables'][key]) for s in plan['seeds']]
    compare_interval(reported,[b-a for a,b in pairs if a is not None and b is not None],('effect',key));effect_count+=1
checks={c['name']:c for c in artifact['summary']['checks']}
for level in plan['levels']:
    if not level['config']['collisions']:continue
    batch=[runs[(level['id'],s)] for s in plan['seeds']]
    raw_status='pass' if max(r['diagnostics']['maxRawMomentumResidual'] for r in batch)<=plan['tolerances']['maxRawMomentumResidual'] else 'fail'
    assert checks[level['id']+': raw angular-momentum budget']['status']==raw_status
    outside=any(r['diagnostics']['outsideSnapshots'] for r in batch)
    unresolved=any(r['diagnostics']['unresolvedExposure'] is None or r['diagnostics']['unresolvedExposure']>plan['tolerances']['maxUnresolvedExposure'] for r in batch)
    coverage='fail' if outside else 'unknown' if unresolved else 'pass'
    assert checks[level['id']+': sampled local coverage']['status']==coverage
assert artifact['summary']['status']==('fail' if any(c['status']=='fail' for c in checks.values()) else 'pass' if all(c['status']=='pass' for c in checks.values()) else 'unknown')
report=dict(schemaVersion=1,artifact=str(PATH.relative_to(ROOT)),sha256=sha(PATH.read_bytes()),sourceHash=artifact['sourceHash'],sourceFilesChecked=len(source),wholeRunsChecked=48,freshSeeds=16,
    verifierCode=dict(path=str(Path(__file__).resolve().relative_to(ROOT)),sha256=sha(Path(__file__).read_bytes())),
    levelSummaryIntervalsRecomputed=summary_count,pairedObservableIntervalsAndVerdictsRecomputed=paired_count,physicalEffectIntervalsRecomputed=effect_count,
    partsChecked=4,declaredGate=artifact['summary']['status'],verdict='all checked provenance, source identity, run membership, original physical settings/budgets and independently recomputed arithmetic agree',
    limitation='Pointwise approximate whole-run t intervals; no simultaneous interval, continuum-error bound or experimental validation established.')
out=ROOT/'assets/convergence-confirmation-independent-audit-v10.json'
with out.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(report,indent=2))

from pathlib import Path
import json,hashlib,math,sys,functools
filenames=['convergence-default-200us-fixed-v10.json','convergence-default-200us-axisymmetric-v10.json','convergence-default-200us-axisymmetric-source-aligned-v10.json','convergence-axisymmetric-refinement-v10.json','convergence-axisymmetric-fine-dt-v10.json','convergence-confirmation-v10.json']
old=json.loads(Path('assets/convergence-default-200us-v1.summary.json').read_text())
numfields={'particlesPerSpecies','cellsAcross','dt','seed','collisions','collisionMethod','collisionSourceAligned'}
physical=lambda c:{k:v for k,v in c.items() if k not in numfields}
reports=[]
physicalMetrics=[]
def near(a,b):
 return a==b or a is not None and b is not None and abs(a-b)<=max(1e-14,1e-10*max(abs(a),abs(b)))
@functools.lru_cache(None)
def independent_t_critical(df):
 # Independently integrate the Student-t PDF, rather than copy the TS table.
 # Round its inverse CDF to the six-decimal precision used by that table.
 coefficient=math.exp(math.lgamma((df+1)/2)-math.lgamma(df/2))/math.sqrt(df*math.pi)
 def cdf(x):
  panels=4096;step=x/panels
  density=lambda v:coefficient*(1+v*v/df)**(-(df+1)/2)
  total=density(0)+density(x)
  total+=sum((4 if j%2 else 2)*density(j*step) for j in range(1,panels))
  return .5+total*step/3
 low,high=0,20
 for _ in range(44):
  middle=(low+high)/2
  if cdf(middle)<.975:low=middle
  else:high=middle
 return round((low+high)/2,6)
def interval(values):
 n=len(values)
 if not n:return {'n':0,'mean':None,'standardError':None,'halfWidth95':None}
 mean=sum(values)/n
 if n<2:return {'n':n,'mean':mean,'standardError':None,'halfWidth95':None}
 se=math.sqrt(sum((x-mean)**2 for x in values)/(n*(n-1)))
 t=independent_t_critical(n-1)
 width=t*se if max(values)-min(values)>256*sys.float_info.epsilon*max(abs(x) for x in values) else None
 return {'n':n,'mean':mean,'standardError':se,'halfWidth95':width}
for filename in filenames:
 p=Path('assets')/filename
 if not p.exists():continue
 a=json.loads(p.read_text());plan=a['plan'];sourcefiles=a['sourceFiles']
 assert a['modelVersion']==10 and a['schemaVersion']==1
 assert a['sourceHash']==hashlib.sha256(json.dumps(sourcefiles,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()
 for f,expected in sourcefiles.items():assert hashlib.sha256(Path(f).read_bytes()).hexdigest()==expected,(filename,f)
 assert plan['seeds']==(list(range(1001,1017)) if filename=='convergence-confirmation-v10.json' else old['plan']['seeds'])
 assert plan['tolerances']==old['plan']['tolerances']
 expected={(l['id'],s) for l in plan['levels'] for s in plan['seeds']}
 assert {(r['level'],r['seed']) for r in a['runs']}==expected and len(a['runs'])==len(expected)
 bylevel={l['id']:[] for l in plan['levels']}
 for r in a['runs']:
  assert r['status']=='complete' and r['sourceHash']==a['sourceHash']
  declared=next(l['config'] for l in plan['levels'] if l['id']==r['level'])
  assert r['config']=={**declared,'seed':r['seed']}
  assert physical(r['config'])==physical(old['plan']['levels'][0]['config'])
  bylevel[r['level']].append(r)
 for level,batch in bylevel.items():
  for key,reported in a['summary']['summaries'][level].items():
   values=[r['observables'][key] for r in batch if r['observables'].get(key) is not None]
   calculated=interval(values)
   for stat in calculated:assert near(reported[stat],calculated[stat]),(filename,level,key,stat)
 checked=0
 for comp in a['summary']['comparisons']:
  for key,reported in comp['observables'].items():
   values=[]
   for seed in plan['seeds']:
    co=next(r for r in bylevel[comp['coarse']] if r['seed']==seed)['observables'].get(key)
    fi=next(r for r in bylevel[comp['fine']] if r['seed']==seed)['observables'].get(key)
    if co is not None and fi is not None:values.append(fi-co)
   calc=interval(values)
   for stat in calc:assert near(reported[stat],calc[stat]),(filename,comp['coarse'],key,stat)
   tolerance=reported['tolerance'];w=calc['halfWidth95'];mean=calc['mean']
   status='unknown'
   if tolerance is not None and len(values)==len(plan['seeds']) and len(values)>=plan['tolerances']['minimumSeeds'] and w is not None:
    if abs(mean)+w<=tolerance:status='pass'
    elif abs(mean)-w>tolerance:status='fail'
   assert reported['status']==status,(filename,comp['coarse'],key,status,reported['status'])
   checked+=1

 effect=plan.get('physicalEffect')
 if effect:
  for key,reported in a['summary']['physicalEffect'].items():
   values=[]
   for seed in plan['seeds']:
    co=next(r for r in bylevel[effect['control']] if r['seed']==seed)['observables'].get(key)
    fi=next(r for r in bylevel[effect['collisional']] if r['seed']==seed)['observables'].get(key)
    if co is not None and fi is not None:values.append(fi-co)
   for stat,value in interval(values).items():assert near(reported[stat],value),(filename,'physical-effect',key,stat)
 for r in a['runs']:
  c=r['raw']['conservation'];col=r['raw']['collisions'];cfg=r['config'];spatial=r['raw']['spatialCollision']
  truth=cfg['densityM3']**2*math.pi*cfg['sourceRadius']**2*cfg['length']*cfg['pulseLengthFraction']
  physicalMetrics.append({'campaign':filename,'level':r['level'],'seed':r['seed'],
   'physicalInitialCanonicalMomentumKgM2S':c['initialCanonicalMomentum'],'physicalCanonicalMomentumScaleKgM2S':c['canonicalMomentumScale'],
   'maximumSampledRawCanonicalDefectKgM2S':c['maxMomentumResidual']*c['canonicalMomentumScale'],
   'maximumSampledCorrectedCanonicalDefectKgM2S':c['maxCorrectedMomentumResidual']*c['canonicalMomentumScale'],
   'physicalEnergyScaleJ':c['energyScaleJ'],'maximumSampledHamiltonianDefectJ':c['maxEnergyResidual']*c['energyScaleJ'],
   'initialSelfExcludedDensitySquaredRatio':spatial['initial']['selfExcludedDensitySquaredIntegral']/truth,
   'rmsRadialPairGapM':math.sqrt(col['pairRadialSeparationSquaredSumM2']/col['pairs']) if col['pairs'] else None,
   'rmsPairSeparationM':math.sqrt(col['pairSeparationSquaredSumM2']/col['pairs']) if col['pairs'] else None,
   'pairCoordinates':spatial['separationCoordinates'],'largeAngularVariancePairFraction':col['largeAnglePairs']/col['pairs'] if col['pairs'] else None,
   'sampledUnresolvedExposure':r['diagnostics']['unresolvedExposure']})
 reports.append({'file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'runs':len(a['runs']),'sourceHash':a['sourceHash'],'sourceFilesChecked':len(sourcefiles),'pairedObservableIntervalsRecomputed':checked,'declaredSummaryGate':a['summary']['status'],'checks':'all run membership, source hashes, physical settings, seeds, budgets, summary moments and paired intervals/verdicts matched'})
print(json.dumps(reports,indent=2))
if len(reports)==len(filenames):
 Path('assets/convergence-physical-metrics-v10.json').write_text(json.dumps({'schemaVersion':1,'units':'Ptheta kg m^2/s; H J; length m. Residual maxima cover recorded snapshots. Corrected Ptheta is bookkeeping only.','runs':physicalMetrics},indent=2)+'\n')
if len(reports)==len(filenames):
 Path('assets/convergence-independent-audit-v10.json').write_text(json.dumps({'schemaVersion':1,'review':'independent Python re-evaluation of frozen TS artifacts; Student-t inverseCDF independently integrated then rounded to the existing table precision; not a simultaneous interval or experimental-validation certificate','auditorSourceSHA256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'campaigns':reports,'wholeRunsChecked':sum(r['runs'] for r in reports)},indent=2)+'\n')

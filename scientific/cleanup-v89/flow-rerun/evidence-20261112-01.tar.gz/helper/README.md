# Fresh V86/V87 physical replay helper

New orchestration only; frozen physical/audit/protocol files are copied without edits. Root owns the serial safe-dev slot and environment. This helper has not yet been executed or tested.

Before the full launch, run the four focused orchestration controls inside that guest:

```text
VERIFIED-PY -m unittest discover -s scientific/cleanup-v89/flow-rerun -p test_rerun.py -v
```

Inside the already prepared safe-dev guest, from the copied repository root:

```text
/work/home/VERIFIED-SCIENTIFIC-ENV/bin/python scientific/cleanup-v89/flow-rerun/rerun.py --source /work/project --destination /work/project/v89-flow-rerun-RUNID
```

`RUNID` must name a destination that does not exist. All runtime packages must exactly match `requirements.txt`; the original runtime is Python3.11.2/zlib1.2.13. Install only inside safe-dev. The helper authenticates current sources against the frozen original V86/V87 source maps, stages separate roots, reruns 26 V86 trajectories and three active-CFL trajectories, performs independent audits, reruns full V86 optical production, and writes raw-byte/decoded-array/float differences from the original. It records every subprocess exit and stops execution failures. Original scientific audit failures remain exit1 in the aggregate; they are never converted to success.

Use `--flow-only` only when the coordinator deliberately splits optical production into another run. That mode still reruns all 29 flow trajectories and their original physical audits but explicitly omits the 84 optical Fourier witnesses and full V86 optical production/summary. It must be reported as reduced scope.

Source/input closure is recorded before execution in `source-closure.json` and verified unchanged afterwards. Baseline copies remain immutable. Python cache files are excluded from new-artifact hashes. `execution.json` reports scientific statuses separately from successful producer completion. App tests/build/typecheck stay root-owned; they are not repeated by this helper.

Historical V86 `results/logs/flow.log` has 26 individual wall times totaling970.53s (16.2min). V87's first trajectory repeats the ~103s first-scenario finest case, with approximate1:2:4 step scaling suggesting another12min; this is an inference, not a measured V87 wall time. Add actual Fourier/optical/audit runtime and environmental variance. Existing field output sizes are34MiB V86 and8.4MiB V87; archived V86 attempt01 is36MiB. This wrapper makes frozen copies for independent differences, so measure final export size before exporting.

# Independent pipeline and qualification review

12 November 2026. Read-only review during the final sealed replay. No project
execution, VM operation or Python edit. Final exported evidence is pending.

## Paths checked

Read complete `run86.py`, `summarize86.py`, `compare86.py`, `panel86.py`,
`replay_fields86.py`, `thermal_reference86.py`, the frozen optical scorer and
the current root report. The optical acceleration's method description was
read, but its mathematical/implementation validation is a separate review.

`run86 final` reruns controls, independent controls, wall reaction, hydro and
the actual FiPy reference before the original audit, panel supplement, optical
comparison and summary. Original audit/panel failure exits are retained while
later evidence is collected. The runner's final nonzero result is not erased
by later software success. Other command failures stop the run explicitly.

`summarize86` gets `allRequiredNumericalPass` from the original failed audit.
Panel failures are separate counts, and cannot set qualification true. The
panel supplement reads the original audit's prediction/source seals and keeps
the failed-original flag false even if every supplemental test passes.
Its per-panel 2x2 integration is exact for squared bilinear interpolation
differences times the cylindrical weight; orders 3/4 are verification checks,
not a changed physical prediction. The supplement is explicitly post hoc.

The comparator checks the complete optical group/alternative inventory and
fixture identities before pairing by full keys. Failed/unavailable groups
remain separately represented. The inherited spectral gate includes flux
capture. All fixed reporting times are retained; no winner timestamp is used
for global qualification. Figures use predeclared edge/temperature/centroid
slices, rather than selecting a slice from best experimental agreement.

## Required distinctions in the final report

- Preserve every original 85 field and 335 quadrature failure if confirmed by
  the final exports. Panel integration is a better diagnostic of the same
  interpolants; it must not rewrite the original frozen acceptance outcome.
- The max-timestep inputs 0.1/0.05/0.025 microseconds are **caps**, not proof of
  corresponding actual timesteps. The parent reports 654/654/655 steps and
  bitwise-identical first two trajectories. Confirm actual sequences from the
  exports. This is an ineffective timestep-refinement contrast, not a
  qualified timestep study or a measured large time-integration error. Further
  accuracy work must decrease the active acoustic CFL or enforce genuinely
  smaller accepted timesteps, under a new protocol.
- Distinguish the initial full-flow attempt from the final source-sealed replay
  after optical acceleration/comparator changes. `replay_fields86` checks all
  26 raw field/history hashes, as well as unchanged physical source files.
  If it passes, numerical optical acceleration did not alter those physical
  fields. Describe fixes as preceding the **final sealed replay**, not all
  earlier scientific work.
- Campaign temperature/Mach maxima come from accepted full-Lie-step endpoints.
  They do not bound intermediate hydro/EM/diffusion temperatures or the
  continuous-time maximum. These already extreme endpoint values suffice to
  expose the physical heating-closure failure.
- First axial cell-center values are used as a symmetric midplane estimate
  in optical input/figures; their observation error needs refinement. They are
  not an independently measured or reconstructed exact wall/axis trace.
- The thermal reference verifies a passive constant-property adiabatic
  eigenmode. Passing it does not qualify strongly heated coupled gas, electron
  energy partition, ionization, radiation or the observed discharge.

## Derived-artifact seal limitation

The summary checks the panel prediction SHA but does not independently verify
its `originalAuditSHA256` or supplemental checker hashes. It also parses
`comparison.json.gz` for figures without checking that file against the
comparison-summary `comparisonSHA256`. The sequential fresh runner should
produce matching files, but summary admission alone does not establish these
bindings under stale/replaced derived artifacts. Final publication review
should explicitly verify those hashes against the exported files and current
checker sources. No stale artifact or wrong final figure is demonstrated here;
this is an admission-coverage limitation, not grounds to change sealed physics.

Final acceptance remains pending actual exported receipts, hashes, plots,
comparison completeness and failed-gate counts. No experimental qualification
is supported by the source review.

# Spatial convergence

Research backend only. The original negative v75 study is retained. Numerical
convergence does not establish experimental accuracy or qualify the playground.

## Causes reproduced before changing the solver

**Comparison aliasing.** The analyzer treated every reference cell as constant
when integrating partial overlaps. On a nonnested 48→36 grid, even an exact
linear axial field acquired a maximum error of 0.2430556 mm (h_reference/12).
Simply, the comparison introduced a staircase before the gas moved. Integrating
the first moments of conservative linear reconstructions in z and s=r² removes
this error while preserving donor-cell integrals. Linear/bilinear, nonuniform
cylindrical and conservation regression controls pass. This was chosen over
dropping the 36-cell case or increasing the error allowance. Reanalyzing old
study01 reduces failing series gates from 74 to 67; its spatial reference still
fails. Old convergence01 is unchanged. The reanalysis is post-processing, not
a new solve or a qualification receipt.

**Excess first-order flux diffusion.** A smooth constant-pressure contact with
linear axial density and +3 m/s velocity produced a negative first-order
numerical mass flux at the tested interior faces. The Rusanov acoustic penalty
acted on the cell-to-cell density jump instead of reconstructed states at the
same face. Simply, numerical spreading overwhelmed the actual flow. Limited
primitive MUSCL reconstruction now uses cylindrical volume centroids and
actual center-to-face distances. Both sides use the same face radius for swirl;
species and angular momentum retain the common numerical mass flux. The
contact regression and closed-domain conservation controls pass. Acoustic
errors decrease strongly over 6–96 cells. This retains the checked conservative
state, SSPRK2 integrator and FiPy source rather than replacing the entire PDE
backend. It is not a claim of exact rotating balance or a general positivity
proof for the full nonlinear system.

**Unresolved developing endwall gradient.** For constant rho=0.001 kg/m³ and
mu=2.54e-5 Pa s, stress-free outer radius, stationary endwalls and
Omega(z,0)=900 sin²(pi z/L), the exact equation is Omega_t=(mu/rho) Omega_zz.
The independent sine expansion has coefficients 8/[pi n(4−n²)] for odd n.
Endwall torque is minus (pi mu R⁴/2) times the axial derivative at the lower wall.
The initial wall derivative is zero; this is not an impulsive wall-speed jump.

At 10 microseconds, with the same 256 backward-Euler steps:

| Axial cells | Uniform error | Tanh wall-grid error | Smallest graded cell |
|---|---:|---:|---:|
| 24 | 250.78% | 11.33% | 0.486 mm |
| 48 | 90.72% | 2.69% | 0.218 mm |
| 96 | 22.93% | 0.528% | 0.103 mm |

Simply, the original uniform mesh placed too few cells inside the wall layer.
The manifest now specifies wall-refined r and z grids. No viscosity, wall
condition, empirical drag or heat correction was fitted. This preserves the
energy-compatible FiPy shear/thermal operators; changing only reported wall
gradients would break their connection to actual momentum loss and heat.
These figures isolate the grid effect and are not coupled-case accuracy claims.

## Coupled verification

Fine wall cells impose a smaller explicit transport timestep. Hydro and binary
diffusion now subcycle separately at CFL 0.3, recording and checking **every**
inner endpoint. Each operator must cover the full outer dt in the right order.
Regression controls reject a missing substep, an earlier failed audit and an
incorrect total elapsed time. A new CFL 0.15 comparison must pass a separate
0.1% profile/observable gate. The outer source/time/joint studies still measure
Lie splitting and backward-Euler errors. The original 2% RMS/observable and
5% local spatial gates are unchanged.

The frozen v76 run starts from safe-dev snapshot
`388744586d65ed768f4725ae26e15580ad8e20ef96948b8eb81baa72e3b1deef`
(1651 files, 263449115 bytes). Its pre-run source map is authoritative.
All 105 tests passed before this run (14.378 s). The copied guest source is
isolated from subsequent host documentation edits.

The full coupled study is in progress; **not numerically qualified**. This
status must be replaced with the actual analysis and admission outcomes after
all requested trajectories finish. A passing isolated control is insufficient.

## Method references

- [Mignone, conservative reconstruction in curvilinear coordinates](https://arxiv.org/abs/1404.0537):
  volume-centroid placement, geometry-aware limiting, primitive reconstruction.
- [MPI-AMRVAC slope limiters](https://amrvac.org/md_doc_2limiter.html):
  monotonized-central reconstruction and limits of scalar TVD guarantees.
- [FiPy cylindrical meshes](https://pages.nist.gov/fipy/en/latest/generated/fipy.meshes.html):
  existing nonuniform cylindrical finite-volume machinery retained for sources.

The physical limitations in the v75 report remain: prescribed conductivity,
natural-Ar transport as an isotope surrogate, common heavy-particle temperature,
no meridional viscous stresses, and unvalidated plasma and wall closures.
The original midpoint-sampled primitive initialization is also retained;
it is not an exact quadrature of the continuum profiles. Refinement includes
that initialization error. The initial pattern was not changed to remove
failed points.
Nothing here establishes Marathon device performance.

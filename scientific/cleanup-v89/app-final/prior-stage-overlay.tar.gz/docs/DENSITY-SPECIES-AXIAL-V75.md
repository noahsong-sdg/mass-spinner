# Evolving density and species: v75

Research backend only. The public playground and experimental qualification
are unchanged. See the [frozen protocol](../scientific/mixture-axial-v75/PROTOCOL.md)
and [manifest](../scientific/mixture-axial-v75/manifest.json).

## What changed and why

The v74 current/thermal solve kept each gas cell's mass and composition fixed.
Consequently it could resolve axial shear and endwall heating, but could not
represent material carrying momentum and heat between cells. In everyday terms,
the gas could spin and warm up without redistributing its density or species.

The new backend evolves cell-integrated total mass, both meridional momenta,
angular momentum, total energy and species-1 mass. Density, pressure, gas inertia
and particle heat capacity are recovered from these inventories, then passed to
the existing FiPy/current solve at each step. Binary diffusion carries equal and
opposite species mass fluxes and their associated enthalpy. Radial velocity also
produces azimuthal current, magnetic braking and Joule heat under the existing
prescribed-conductivity, no-Hall Ohm law.

For each cell, the thermodynamic reconstruction is

```
rho = M/V
N = M1/m1 + (M-M1)/m2
I = M <r²>
U = Etotal - (Mr²+Mz²)/(2M) - L²/(2I)
T = U/[(3/2) kB N]
p = (2/3) U/V
```

Thus transporting species changes particle heat capacity, transporting total
mass changes inertia, and pressure work exchanges thermal and kinetic energy
without an extra corrective heat term.

This conservative transport layer keeps the previously checked source solve
and exposes its coupling error to timestep refinement. A reduced incompressible
model would remove the density dynamics requested here; replacing the complete
electrical and thermal backend would discard existing independent verification.
This implementation remains a research model, rather than a replacement for a
general plasma or multicomponent Navier–Stokes code.

## Corrections made while tracing the execution path

- **Angular-momentum and species fluxes:** independently diffusing these
  conserved fields with a Rusanov penalty produced angular transport without
  mass transport. Simply, a stationary rotating gas could lose its rotation
  profile numerically. Both now use the common numerical mass flux and upwind
  specific angular momentum/composition. Tests cover stationary rotation and
  uniform composition under changing density.
- **Time-dependent FiPy storage:** updating only diagnostic density would leave
  the transient coefficient stale. Both the actual angular-inertia coefficient
  and energy-ledger inertia are refreshed from transported mass, together with
  the exact binary particle heat capacity. A reused solver is compared against
  a newly constructed one at the changed density. Refreshing the coefficients
  directly fixes the stored-state mismatch without reconstructing the full
  solver on every step.
- **Species energy flux:** separate donor temperatures created heat transport
  between identical species labels. A common face temperature in the binary
  enthalpy flux preserves that physical invariant. Tests cover identical masses,
  heat-flux sign and local independent reconstruction.
- **Radial moment diagnostic:** an arithmetic radial midpoint biases a
  cylindrical cell's mass centroid. The diagnostic now uses the exact
  volume-mean radius; a uniform cylinder recovers its centroid of 2R/3.
- **Qualification sensitivity:** initial heterogeneity can mask errors in small
  transport increments. Density and composition changes now receive their own
  response-normalized refinement gates, alongside the complete fields. This
  measures the requested dynamics rather than only their initial background.
- **Composite temperature domain:** the inherited thermal source permits
  temperatures above the diffusion correlation's 418 K ceiling. In particular,
  a final source step could return an unsupported state before another
  diffusion step had a chance to reject it. The composite now admits only
  300–418 K at construction, source input/output and accepted split-stage
  boundaries. The independent source audit enforces the same limit. Nonlinear
  trial states retain their actual wider thermal-property domain because no
  diffusion coefficient is evaluated there. This enforces the real model
  boundary without clipping temperatures or breaking the source line search.

## Physical scope

The case is a closed cylinder containing nominal 36 u/40 u neutral species at
350 K, using natural-argon properties as explicit isotope approximations.
It is not lithium, an ionization model, or a published Marathon operating point.
The gas-property intersection is 300–418 K. Electrical conductivity is prescribed;
changing density affects current through velocity and thermal feedback, not a
derived conductivity closure. The sinusoidal wall voltage is a manufactured
distributed boundary condition, not a claim about a continuous metal electrode.
Applying the electrical force and Joule heat to this common heavy-gas fluid
assumes local carrier-to-gas momentum and energy transfer. Neither the carrier
population nor its equilibration time is derived here.

The equations include compressible inviscid meridional flow, azimuthal viscosity,
heat conduction, binary pressure diffusion, species enthalpy, wall heat storage
and electrical work. They omit meridional viscous stresses, Soret/Dufour terms,
electron energy, ionization, Hall current, induction, sheaths and extraction.
Natural-argon self diffusion is an approximation to binary isotope diffusion.
The blocked face flux is consistent and monotone; it is not claimed to integrate
the finite-face Maxwell–Stefan equation exactly or prove global entropy decay.

Hydrodynamic numerical mixing is truncation error, not measured viscous heat.
The implicit source's backward-Euler loss remains a separately recorded
numerical sink. No clipping, inventory renormalization or energy correction is
used to obtain a passing ledger.

In the raw observations, `jouleW` is the r–z electrical solve's Joule power;
`radialMotionalJouleW` is the separate azimuthal-current contribution. Their
sum is the instantaneous total. The magnetic stage integrates its heat
analytically, rather than using endpoint power multiplied by the timestep.

The previous experimental velocity/field-scaling discrepancies remain
unresolved. This extension does not supersede the
[v74 qualification limits](AXIAL-CURRENT-THERMAL-V74.md#physical-limitations).

## Evidence and acceptance

The current run uses independent per-stage reconstructions, local electrical,
momentum and thermal residuals, global conservation ledgers, analytical acoustic
and diffusion controls, and six deliberately corrupted coupled states. Grid,
timestep, radial, axial, solver-tolerance and reference refinements are required
by the protocol. Passing a local ledger alone is insufficient for qualification.

The first full study was frozen before the final composite-domain and output-
admission review corrections. Its original producer hash map is retained. Later
checks must identify their own source snapshot separately; they cannot rewrite
the original provenance or claim to have run before they existed.

Numerical result artifacts and final convergence status will be recorded here
after the complete frozen study and independent review.

## Primary references

- [NIST TN 2279](https://nvlpubs.nist.gov/nistpubs/TechnicalNotes/NIST.TN.2279.pdf):
  natural-argon self-diffusion correlation and stated temperature interval.
- [Sandia Fuego conservation models](https://www.sandia.gov/files/sierra/Fuego_Users_5_26/theory/mathmodels/laminar.html):
  mass, species, energy and axisymmetric-swirl bookkeeping; its low-Mach closure
  is not substituted for this backend's compressible equations.
- [Independent equation review](reviews/v75-equations.md),
  [validation design](reviews/v75-validation-design.md), and
  [transport sources](reviews/v75-transport-sources.md).

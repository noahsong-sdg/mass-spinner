# First public source snapshot

The public repository contains the application, its required 3D assets, Blender
scripts, application tests, selected scientific fixtures and compact research
evidence. The historical README is retained separately from the short overview.

Excluded material includes installed dependencies, local tools and credentials,
downloaded papers, full extracted article text, historical release copies, VM
exports and large raw research runs. The full local scientific directory is
approximately 19 GB; this is a curated source publication rather than a complete
archive. Some historical controller commands and documentation links refer to
excluded artifacts and cannot be replayed from this repository alone.

The intended self-contained checks are the README's application commands and
the following standard-library research checks:

```sh
python3 -m unittest discover -s scientific/diagnostic-v71 -p 'test_*.py' -v
python3 scientific/diagnostic-v71/run_report.py
python3 -m unittest discover -s scientific/field-v70 -p 'test_*.py' -v
```

All maintainer execution uses copied source in an Apple safe-dev VM. An initial
test-log command targeted the root-owned `/work` directory and failed before
executing tests; using the writable `/work/home` directory corrected that runner.
No runtime permission or isolation boundary was weakened.

Publication checks do not establish physical accuracy or deployed browser/GPU
behavior. The v71 optical operator is research-only, with no production caller.
Its initial coarse-grid failure remains documented, and its acceptance tolerance
was not relaxed. See [the diagnostic report](DIAGNOSTIC-V71.md) and
[the experimental limits](FIRST-ORDER-ACCURACY-V70.md).

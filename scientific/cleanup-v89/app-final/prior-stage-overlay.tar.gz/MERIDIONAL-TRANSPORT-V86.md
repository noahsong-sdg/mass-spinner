# Coupled meridional transport: conditional release, not device validation

12 November 2026. Research backend; production physics and the live playground
are unchanged. Results and final checks are being completed.

## Problem and root cause

The previous current-driven torsional model includes axial electric current,
axial viscosity and endwall braking, but extends prescribed radial material
profiles along the axis. Its nonzero pressure-compatibility loop does not give
a circulation speed. Density, radial/axial momentum, angular momentum and
energy must respond together; adding an empirical drag or circulation amplitude
would not close those equations.

In plain terms, calculating rotation alone leaves out how gas moves, expands
and carries heat when the required pressure cannot balance it.

## Implementation and tool choice

The new, separate backend reuses V75's conservative cylindrical finite-volume
MUSCL/Rusanov SSPRK2 transport. Its state contains integrated mass, radial and
axial momentum, angular momentum, total energy and a passive composition
coordinate. Both masses are natural Ar here; that coordinate does not predict
ionization. Pressure follows a monatomic ideal-gas EOS. All advected quantities
share the same mass flux. Total energy contains all three kinetic components.

Actual **scikit-fem 12.0.2** assembles the full cylindrical Newtonian deviatoric
stress and adiabatic conduction, including hoop strain and cross derivatives.
The hybrid method uses Q1 fields on FV centroid/boundary nodes and actual FV
mass/inertia/heat capacities. Zero-capacity natural boundary traces are solved,
not treated as artificial gas cells. Stationary walls have zero velocity;
axis/midplane conditions distinguish regularity from no slip. Quadrature
dissipation and backward-Euler damping return to internal energy, with local
stress-energy redistribution retained. Convergence is required; this assembly
library does not by itself qualify the hybrid method.

A monolithic Hall source step solves potential and both transverse momenta.
For positive stored Hall magnitude h,

`E'r=-phi_r+B u_theta`, `E'theta=-B u_r`,
`Jr=sigmaP E'r-h E'theta`, `Jtheta=h E'r+sigmaP E'theta`.

Thus radial motion affects charge, radial magnetic braking and rotational
drive. Series-segment current, force, electrode work and Ohmic heat use the
same geometry. The ledger enforces `J.E=Qohm+u.(J×B)`; the implicit kinetic
defect is numerical heat, not an additional external source. Energy is not
counted twice.

An **actual FiPy** scalar heat solve and an analytic cylindrical eigenmode
provide separate verification. OpenFOAM and PETSc were reviewed as stronger
general thermofluid foundations. Neither has the required weakly ionized Hall,
contact and optical closures ready to insert here. This bounded extension
reuses previously tested transport and established matrix assembly without claiming a
complete industrial plasma-CFD solver. See
[tool review](scientific/meridional-v86/CODE-REVIEW.md) and
[equations](scientific/meridional-v86/EQUATION-REVIEW.md).

## Fixed inputs and physical limits

The [protocol](scientific/meridional-v86/PROTOCOL.md) was committed before full
predictions, with a separately recorded pre-campaign quadrature detail after
the pilot. Same four source electrical scenarios, both anode positions and
prescribed 100 A per branch. No current or velocity fitting. The finite anode
uses the published 2 cm width. A uniform 4 mm radius cathode disk is an
explicit regularization; the source gives a hollow-cathode inner radius, not
its emitting-current footprint.
These are the 1979 argon benchmark conditions, not Marathon machine geometry
or an experimental qualification of Marathon's design.

Closed, adiabatic, stationary walls and prescribed microscopic electrical
coefficients define a **conditional release**. Density and temperature evolve,
but electron temperature, ionization and conductivity do not close themselves.
All Ohmic heat goes to one heavy-gas temperature; no measured electron–heavy
energy partition, cooling law or injection rate was supplied. Constant
published viscosity and a monatomic Eucken conductivity are mathematical
control coefficients, not verified properties at extreme temperature.

The original papers do not supply the missing matched thermal boundaries.
The 1980 paper's 400 K wall is a theoretical assumption in a different
apparatus, not a measured 1979 boundary. A closed system with positive
electrical power has no thermal steady state. We therefore report all fixed
times 0,1,2,4 microseconds, without choosing the best-matching clock.

## Optical and audit safeguards

The new two-sided LOS operator includes radial Doppler motion. Symmetry
cancels its centroid contribution but preserves broadening and possible mode
changes. Measured brightness and all 72 frozen thermal/instrument/estimator
alternatives remain. On an overheated conditional state these are diagnostic
sensitivities, not predictions of that gas's emission. Every time is scored
separately against the unchanged previously viewed development measurements.

Independent review found and fixed four comparator defects before the final
sealed replay: positional pairing of alternatives, duplicate/missing groups,
unchecked source/diagnostic seals and ambiguous sightline ordering. Pairing now
uses full identities, requires the complete group/alternative inventory,
canonicalizes point IDs and rejects stale evidence. Explicit unavailable cases
cannot count as zero experimental matches or successful convergence.

The first full optical run exposed an additional integration bug: prediction
stores sightline IDs/radii, while its checker expected the source records'
extra extraction-range metadata too. The gas had not moved incorrectly; two
representations of the same sightlines failed an exact dictionary comparison.
The fix projects only the expected fixture onto the predictor's declared
ID/radius contract. It still rejects changed IDs/radii or extra prediction keys
and seals the complete original diagnostic file. This preserves provenance
without weakening checks or inventing propagation of coordinate uncertainty.
A regression uses the actual fixture and predictor, with three corruption
checks. The failed attempt is retained under `results/failure02`; predictions
are replayed with final source seals before scoring.

Saved-state auditing independently reconstructs EOS/inertia, global
mass/species/energy and the reporting-time budgets. Intermediate history has
producer residuals rather than every intermediate state; its local rows are
not independently reconstructed from those scalar logs. Separate source tests
rebuild charge/force/heat directly. Fixed-volume spatial/timestep and physical
quadrature gates remain independent of experimental scores. Failures are
retained; no thresholds, heating fractions or contact sizes are tuned.

The independent stress review found no demonstrated sign or global-energy
defect. It preserves three limits: quadrature heat placement is not an exact
FE/FV-overlap integration; Q1 conduction has no general discrete maximum
principle on arbitrary stretched grids; and this first campaign does not save
a full-trajectory wall-reaction ledger. Separate operator controls test angular
momentum against stationary-wall reaction, but cannot replace that trajectory
diagnostic. See [independent review](scientific/meridional-v86/DIFFUSION-INDEPENDENT.md).

## Results and verification

Both full campaigns completed all 26 flow cases. The first source snapshot,
fields and failed audit remain under `results/attempt01`. Original gates
reported **85 field failures and 335 quadrature failures**. Those failures are
retained, not replaced by a favorable supplemental analysis.

Two distinct numerical problems were identified. Global Gauss sampling crosses
piecewise-bilinear interpolation knots and under-resolves some field-comparison
integrals. A separately labeled post hoc checker instead integrates each union
panel exactly with a 2×2 Gauss rule, with 3×3/4×4 witnesses. This diagnoses
integration error; it cannot waive actual field error or the original failed
qualification.

The nominal 0.1/0.05/0.025 microsecond cap contrast also fails to establish
temporal convergence. Acoustic CFL already limits the finest calculation:
the first two schedules have 654 steps and are identical; the third has 655.
Actual CFL or active-timestep refinement is still needed. Lowering an inactive
cap is not evidence of smaller timesteps.

The full spectral comparison initially exposed a computational bottleneck.
An explicitly selected Fourier Gaussian-mixture integrator retains analytic
bin integration, exact-CDF flux/mode checks and the unchanged direct-CDF
reference. It changes numerical integration only. Its gates were recorded
before optical predictions and target scoring. The 24 standalone controls and
all **84 predeclared actual-field witnesses passed**. Direct-CDF evaluation took
3.902 s and Fourier evaluation 0.276 s on that witness set; this is a measured
local speedup, not a whole-campaign performance guarantee. **All 26 replayed
field packets, saved states and histories are bitwise identical** to attempt01.
The new prediction manifest differs because it seals the final numerical
optical integration sources, not because physical flow fields changed.

Final result tables, source seals, exact checks and independent evidence review
will be recorded here after completion. Temperature and Mach maxima refer to
accepted full-split endpoints, not continuous or intermediate-suboperator
extrema. The retained pilot already exposes severe local overheating rather
than experimental closure.

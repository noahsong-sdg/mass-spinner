"""One-process analysis ablation, not canonical qualification. Safe-dev only."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

SOURCE = Path(__file__).resolve().parents[1]/'mixture-axial-v75'
sys.path.insert(0, str(SOURCE))
import analyze as analysis


def compare_profiles(coarse, coarse_case, reference, reference_case, manifest):
    cf, rf = [analysis.primitives(t, e) for t, e in ((coarse, coarse_case), (reference, reference_case))]
    ci, ri = [analysis.primitives(t, dict(q=t['initialQ'], solidK=t['initialSolidK']))
              for t in (coarse, reference)]
    for fields, start in ((cf, ci), (rf, ri)):
        fields['densityChange'] = fields['density']-start['density']
        fields['YChange'] = fields['Y']-start['Y']
    result = {}
    for name in analysis.FIELDS:
        region = 'wall' if name == 'solid' else 'r'
        cr, rr = [np.asarray(t['setup'][region]) for t in (coarse, reference)]
        prolong = lambda field: analysis.restrict_linear(field, reference['setup']['z'],
            coarse['setup']['z'], rr*rr, cr*cr)
        weight = np.diff(reference['setup']['z'])[:, None]*np.diff(rr*rr)[None, :]
        if name in ('Y', 'YChange'):
            rho = prolong(cf['density'])
            analysis.require(np.all(rho > 0), 'Nonpositive reconstructed density')
            value = prolong(cf['density']*cf['Y'])/rho
            if name == 'YChange':
                value -= prolong(ci['density']*ci['Y'])/prolong(ci['density'])
            weight = weight*rf['density']
        else:
            value = prolong(cf[name])
        error = value-rf[name]
        scale = analysis.response_scale(name, rf[name], manifest)
        rms = float(np.sqrt(np.sum(weight*error*error)/np.sum(weight)))
        maximum = float(abs(error).max())
        result[name] = dict(rmsAbsolute=rms, maxAbsolute=maximum, scale=scale,
            rmsNormalized=rms/scale, maxNormalized=maximum/scale,
            weighting='mass' if name in ('Y', 'YChange') else 'cylindrical volume')
    return result


if __name__ == '__main__':
    raw_path, output = map(Path, sys.argv[1:])
    # Explicit one-off ablation hook. The canonical file is never changed;
    # any eventual admitted implementation must not rely on this mutation.
    analysis.compare_profiles = compare_profiles
    result = analysis.analyze(json.loads(raw_path.read_text()))
    result.update(scope='Analysis ablation only; canonical verdict unchanged',
        inputSha256=hashlib.sha256(raw_path.read_bytes()).hexdigest(),
        sourceSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest())
    output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(passed=result['numericallyQualified'],
        failedGates={name: [g for g in series['gates'] if not g['passed']] for name, series in result['series'].items()},
        references={name: row['passed'] for name, row in result.items() if isinstance(row, dict) and 'passed' in row})))

"""Initialization ablation for the residual coarse axial curve; safe-dev only.

Changes only how the SAME continuum initial functions are integrated. Pure
Euler evolution isolates initialization/transport from the FiPy/current source.
This probe is not a canonical production trajectory or qualification receipt.
"""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np
from numpy.polynomial.legendre import leggauss

SOURCE = Path(__file__).resolve().parents[1]/'mixture-axial-v75'
sys.path.insert(0, str(SOURCE))
from run import configuration
from analyze import compare_profiles


def integrated_initial(flow, manifest, order=12):
    nodes, weights = leggauss(order)
    r, z = flow.r, flow.z
    rp = (r[:-1, None]+r[1:, None]+np.diff(r)[:, None]*nodes)/2
    zp = (z[:-1, None]+z[1:, None]+np.diff(z)[:, None]*nodes)/2
    rr, zz = rp[None, :, None, :]/r[-1], zp[:, None, :, None]/z[-1]
    dv = (np.pi/2*np.diff(z)[:, None, None, None]*np.diff(r)[None, :, None, None]
          *rp[None, :, None, :]*weights[None, None, :, None]*weights[None, None, None, :])
    pattern = np.cos(np.pi*rr)*np.cos(np.pi*zz)
    rho = manifest['densityKgM3']*(1+.04*pattern)
    y = .5+.06*pattern
    temperature = manifest['initialGasK']+2*np.cos(np.pi*zz)*(1-rr*rr)
    omega = manifest['initialOmegaRadS']*(1-rr*rr)*np.sin(np.pi*zz)**2
    ur, uz = 2*np.sin(np.pi*rr)*np.cos(np.pi*zz), np.cos(np.pi*rr)*np.sin(np.pi*zz)
    internal = 1.5*1.380649e-23*rho*temperature*(y/flow.masses[0]+(1-y)/flow.masses[1])
    spin = (rr*r[-1]*omega)**2
    fields = (rho, rho*ur, rho*uz, rho*omega*(rr*r[-1])**2,
              internal+.5*rho*(ur*ur+uz*uz+spin), rho*y)
    return np.array([np.sum(dv*v, axis=(-2, -1)) for v in fields])


def evolve(manifest, nz, integrated):
    flow, setup, q, solid = configuration(manifest, 48, nz)
    if integrated:
        q = integrated_initial(flow, manifest)
    initial = q.copy()
    elapsed = 0.
    final = max(manifest['timesS'])
    while elapsed < final:
        dt = min(final-elapsed, flow.stable_dt(q, .15))
        q = flow.advance(q, dt)
        elapsed += dt
    endpoint = dict(q=q, solidK=solid)
    return dict(nr=48, nz=nz, setup=setup, initialQ=initial, initialSolidK=solid,
                endpoint=endpoint, integrated=integrated)


if __name__ == '__main__':
    manifest = json.loads((SOURCE/'manifest.json').read_text())
    rows = []
    for integrated in (False, True):
        cases = [evolve(manifest, n, integrated) for n in (6, 12, 24, 36, 48)]
        reference = cases[-1]
        for case in cases[:-1]:
            error = compare_profiles(case, case['endpoint'], reference, reference['endpoint'], manifest)
            rows.append(dict(nz=case['nz'], integrated=integrated,
                             vz=error['vz'], initialTotals=case['initialQ'].sum(axis=(1, 2)).tolist()))
    result = dict(rows=rows,
        sourceHashes={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in (Path(__file__), SOURCE/'flow.py', SOURCE/'run.py', SOURCE/'analyze.py')},
        scope='Pure-hydro initialization ablation; no source/thermal/canonical qualification')
    Path(sys.argv[1]).write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps([dict(nz=r['nz'], integrated=r['integrated'], rms=r['vz']['rmsNormalized']) for r in rows]), flush=True)

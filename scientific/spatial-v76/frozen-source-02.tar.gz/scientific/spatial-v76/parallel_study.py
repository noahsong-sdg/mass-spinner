"""Resume sealed independent trajectories concurrently inside one safe-dev VM.

No physical source or manifest edits. Completed checkpoints are preserved;
an interrupted, unsaved trajectory is recomputed in full. Run offline only.
"""
import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
import hashlib
from importlib.metadata import version
import json
import multiprocessing
from pathlib import Path
import platform
import sys

SOURCE = Path(__file__).resolve().parents[1]/'mixture-axial-v75'
sys.path.insert(0, str(SOURCE))
from run import admit_checkpoint, hashes, requests, serial, trajectory


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workers', type=int, choices=(1, 2, 3), default=3)
    args = parser.parse_args()
    original_bytes = args.output.read_bytes()
    report = json.loads(original_bytes)
    manifest = json.loads((SOURCE/'manifest.json').read_text())
    source_map = hashes()
    runtime = dict(python=platform.python_version(), numpy=version('numpy'),
                   scipy=version('scipy'), fipy=version('fipy'))
    keys = admit_checkpoint(report, dict(manifest=manifest, sourceHashes=source_map, preRunRuntime=runtime))
    remaining = [k for k in requests(manifest) if k not in keys]
    report.setdefault('orchestration', []).append(dict(
        runnerSha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        resumedInputSha256=hashlib.sha256(original_bytes).hexdigest(), workers=args.workers,
        completedBefore=len(keys), pending=[list(k) for k in remaining]))
    def save():
        if hashes() != source_map:
            raise AssertionError('Scientific source changed during execution')
        temporary = args.output.with_suffix('.checkpoint.tmp')
        temporary.write_text(json.dumps(report, default=serial, indent=2, allow_nan=False)+'\n')
        temporary.replace(args.output)
    save()
    with ProcessPoolExecutor(max_workers=args.workers, mp_context=multiprocessing.get_context('spawn')) as pool:
        pending = {pool.submit(trajectory, manifest, *key): key for key in remaining}
        for future in as_completed(pending):
            key = pending[future]
            try:
                report['cases'].append(future.result())
            except Exception as error:
                report['failures'].append(dict(zip(('nr', 'nz', 'nt', 'mode'), key), error=repr(error)))
            save()
            print(f'CHECKPOINT {len(report["cases"])}/{len(requests(manifest))} failures={len(report["failures"])}', flush=True)
    raise SystemExit(1 if report['failures'] else 0)
